#pragma once

// Incluir SDKDDKVer.h define a plataforma Windows mais alta dispon�vel.

// Se voc� deseja compilar sua aplica��o para vers�es anteriores de plataformas Windows, inclua WinSDKVer.h e
// ajuste a macro _WIN32_WINNT para a plataforma que voc� deseja suportar antes de incluir SDKDDKVer.h.

#include <SDKDDKVer.h>
