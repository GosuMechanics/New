// LoL base.cpp : Define as fun��es exportadas para a aplica��o DLL.
//

#include "stdafx.h"


