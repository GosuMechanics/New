// stdafx.h : arquivo de inclus�o para inclus�es do sistema padr�es,
// ou inclus�es espec�ficas de projeto que s�o utilizadas frequentemente, mas
// s�o modificadas raramente
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Remova itens raramente utilizados dos cabe�alhos Windows
// Arquivos de Cabe�alho Windows:
#include <windows.h>



// TODO: adicionar refer�ncias de cabe�alhos adicionais que seu programa necessita
